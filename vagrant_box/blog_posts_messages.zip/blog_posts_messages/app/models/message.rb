class Message < ApplicationRecord
    belongs_to :post
end
