class Blog < ApplicationRecord
    has_many :post
end
